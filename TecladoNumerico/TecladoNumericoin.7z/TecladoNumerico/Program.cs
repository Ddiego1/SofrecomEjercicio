﻿using System;
using System.Threading;
using System.Globalization;
using System.Collections.Generic;

namespace TecladoNumerico
{
    public class Program
    {
        public static int newNumber;

        public static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            llenarlista();
            Console.WriteLine("Ingrese los numeros");
            string pipo =Console.ReadLine();

            List<Letras> ndeah = new List<Letras>();
        }

        public static void llenarlista()
        {
            List<Letras> abecedario = new List<Letras>();
            char abc = 'a';
            int num = 2;
            for(num = 2; num <=9; num++)
            {
                if (num == 9 || num ==7)
                {
                    for (int j = 1; j <= 4; j++)
                    {
                        calcularlista(j);
                        int id = num * newNumber;
                        abecedario.Add(new Letras { numero = id, letra = abc });
                        abc++;
                    }
                }
                else
                {
                    for (int j = 1; j <= 3; j++)
                    {
                        calcularlista(j);
                        int id = num * newNumber;
                        abecedario.Add(new Letras { numero = id, letra = abc });
                        abc++;
                    }
                }
            }
        }

        public static int calcularlista(int numsec)
        {
            switch(numsec)
            {
                case 1:
                    newNumber = 1;
                    break;
                case 2:
                    newNumber = 11;
                    break;
                case 3:
                    newNumber = 111;
                    break;
                case 4:
                    newNumber = 1111;
                    break;
            }
            return newNumber;
        }

    }
}
