﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TecladoNumerico
{
    public class Letras
    {
        public int numero { get; set; }

        public char letra { get; set; }
    }
}
